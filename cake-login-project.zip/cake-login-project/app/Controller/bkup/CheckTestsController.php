<?php

App::uses('AppController', 'Controller');

/**
 * TaxSettings Controller
 *
 * @property TaxSetting $TaxSetting
 * @property PaginatorComponent $Paginator
 */
class CheckTestsController extends AppController {

    public $components = array('Paginator');


    public function admin_index()
    {
        

    }

}

