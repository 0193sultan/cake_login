<?php
App::uses('AppController', 'Controller');
/**
 * Employees Controller
 *
 * @property Employee $Employee
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class EmployeesController extends AppController {

/**
 * Components
 *
 * @var array
 */
public $components = array('Paginator', 'Session');


/**
 * admin_index method
 *
 * @return void
 */
public function admin_index() {
	$this->set('page_title','Employee List');
	$this->Employee->recursive = 0;
	$this->paginate = array('order' => array('Employee.id' => 'DESC'));
	$this->set('employees', $this->paginate());
}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
public function admin_view($id = null) {
	$this->set('page_title','Employee Details');
	if (!$this->Employee->exists($id)) {
		throw new NotFoundException(__('Invalid employee'));
	}
	$options = array('conditions' => array('Employee.' . $this->Employee->primaryKey => $id));
	
	$this->set('employee', $this->Employee->find('first', $options));
}

/**
 * admin_add method
 *
 * @return void
 */
public function admin_add() {
	$this->set('page_title','Add Employee');
	$employee_id=0;
	if ($this->request->is('post')) {
		$this->Employee->create();
		$this->request->data['Employee']['created_at'] = $this->current_datetime();
		$this->request->data['Employee']['created_by'] = $this->UserAuth->getUserId();
		$this->request->data['Employee']['date_of_birth']=date('Y-m-d',strtotime($this->request->data['Employee']['date_of_birth']));
		$this->request->data['Employee']['joining_date']=date('Y-m-d',strtotime($this->request->data['Employee']['joining_date']));
		if ($this->Employee->save($this->request->data)) {
			$employee_id=$this->Employee->getLastInsertId();
			$file=$this->request->data['EmployeeChild']['file'];
			$this->loadModel('EmployeeChild');
			$data['EmployeeChild']['employee_id']=$employee_id;
			//$this->EmployeeChild->create();
			for($i=0;$i<2;$i++){
				$this->EmployeeChild->create();
				move_uploaded_file($file[$i]['tmp_name'], WWW_ROOT . 'uploads_files/birth_cirtificate/' . $file[$i]['name']);
				$data['EmployeeChild']['name']=$this->request->data['EmployeeChild']['name'][$i];
				$data['EmployeeChild']['dob']=date('Y-m-d',strtotime($this->request->data['EmployeeChild']['dob'][$i]));
				$data['EmployeeChild']['edu_status_id']=$this->request->data['EmployeeChild']['edu_status_id'][$i];
				$data['EmployeeChild']['file_path']=$file[$i]['name'];
				//print_r($data['EmployeeChild']);
				if($data['EmployeeChild']['name']!='' && $data['EmployeeChild']['dob']!=''){
					$this->EmployeeChild->save($data['EmployeeChild']);
				}
			}
			$this->loadModel('EmployeeAllowance');
			$this->EmployeeAllowance->create();
			$this->request->data['EmployeeAllowance']['employee_id']=$employee_id;
			if($this->EmployeeAllowance->save($this->request->data['EmployeeAllowance'] )){
				$this->loadModel('EmployeeRecovery');
				$this->EmployeeRecovery->create();
				$this->request->data['EmployeeRecovery']['employee_id']=$employee_id;
				if($this->EmployeeRecovery->save($this->request->data['EmployeeRecovery'])){
				$this->Session->setFlash(__('The employee has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			}}
		} else {
			$this->Session->setFlash(__('The employee could not be saved. Please, try again.'), 'flash/error');
		}
	}
	$employeeGrades = $this->Employee->EmployeeGrade->find('list');
	$scales = $this->Employee->Scale->find('list');
	$departments=$this->Employee->Department->find('list');
	$designations = $this->Employee->Designation->find('list');
	$basics = $this->Employee->Basic->find('list',array('conditions'=>array('Basic.basic_type'=>0)));
	$newBasics = $this->Employee->Basic->find('list',array('conditions'=>array('Basic.basic_type'=>1)));
	$quotas = $this->Employee->Quota->find('list');
	$employeeTypes = $this->Employee->EmployeeType->find('list');
	$religions = $this->Employee->Religion->find('list');
	$jobStatuses = $this->Employee->JobStatus->find('list');
	$this->loadModel('BankInfo');
	$banks = $this->BankInfo->find('list');
	//$banks = array();
	$sexes = $this->Employee->Sex->find('list');
	$maritalStatuses = $this->Employee->MaritalStatus->find('list');
	$livingStatuses = $this->Employee->LivingStatus->find('list');
	$this->loadModel('edu_status');
	$eduStatuses=$this->edu_status->find('list');
	$this->set(compact('employeeGrades', 'scales','departments', 'designations', 'basics', 'newBasics', 'quotas', 'employeeTypes', 'religions', 'jobStatuses', 'banks', 'sexes', 'maritalStatuses', 'livingStatuses','eduStatuses'));
}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
public function admin_edit($id = null) {
	$this->set('page_title','Edit Employee');
	$this->Employee->id = $id;
	if (!$this->Employee->exists($id)) {
		throw new NotFoundException(__('Invalid employee'));
	}
	//print_r($this->request->data);exit();
	if ($this->request->is('post') || $this->request->is('put')) {
		$this->request->data['Employee']['updated_by'] = $this->UserAuth->getUserId();
		$this->request->data['Employee']['date_of_birth']=date('Y-m-d',strtotime($this->request->data['Employee']['date_of_birth']));
		$this->request->data['Employee']['joining_date']=date('Y-m-d',strtotime($this->request->data['Employee']['joining_date']));
		if ($this->Employee->save($this->request->data)) {
			$file=$this->request->data['EmployeeChild']['file'];
			$this->loadModel('EmployeeChild');
			$data['EmployeeChild']['employee_id']=$id;
			$this->EmployeeChild->create();
			for($i=0;$i<2;$i++){
				$this->EmployeeChild->id=$this->request->data['EmployeeChild']['id'][$i];
				if(!empty($file[$i]['tmp_name'])){
					//unlink(WWW_ROOT . 'uploads_files/birth_cirtificate/'.$this->request->data['EmployeeChild']['file_path'][$i]);
					move_uploaded_file($file[$i]['tmp_name'], WWW_ROOT . 'uploads_files/birth_cirtificate/' . $file[$i]['name']);
					$data['EmployeeChild']['file_path']=$file[$i]['name'];
				}
				else{
					$data['EmployeeChild']['file_path']=$this->request->data['EmployeeChild']['file_path'][$i];
				}
				$data['EmployeeChild']['name']=$this->request->data['EmployeeChild']['name'][$i];
				$data['EmployeeChild']['dob']=date('Y-m-d',strtotime($this->request->data['EmployeeChild']['dob'][$i]));
				$data['EmployeeChild']['edu_status_id']=$this->request->data['EmployeeChild']['edu_status_id'][$i];
				//$data['EmployeeChild']['file_path']=$file[$i]['name'];
				//print_r($data['EmployeeChild']);
				if($data['EmployeeChild']['name']!='' && $data['EmployeeChild']['dob']!=''){
					$this->EmployeeChild->save($data['EmployeeChild']);
				}
			}
			$this->loadModel('EmployeeAllowance');
			$this->request->data['EmployeeAllowance']['employee_id']=$id;
			$this->EmployeeAllowance->id=$this->request->data['EmployeeAllowance']['id'];
			if($this->EmployeeAllowance->save($this->request->data['EmployeeAllowance'] )){
				$this->loadModel('EmployeeRecovery');
				$this->request->data['EmployeeRecovery']['employee_id']=$id;
				$this->EmployeeRecovery->id=$this->request->data['EmployeeRecovery']['id'];
				if($this->EmployeeRecovery->save($this->request->data['EmployeeRecovery'])){
				$this->Session->setFlash(__('The employee has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			}}
		} else {
			$this->Session->setFlash(__('The employee could not be saved. Please, try again.'), 'flash/error');
		}
	} else {
		$options = array('conditions' => array('Employee.' . $this->Employee->primaryKey => $id));
		$this->Employee->recursive=1;
		$this->request->data= $this->Employee->find('first', $options);
		//print_r($this->request->data);exit();
	}
	$employeeGrades = $this->Employee->EmployeeGrade->find('list');
	$scales = $this->Employee->Scale->find('list');
	$departments=$this->Employee->Department->find('list');
	$designations = $this->Employee->Designation->find('list');
	$basics = $this->Employee->Basic->find('list',array('conditions'=>array('Basic.basic_type'=>0)));
	$newBasics = $this->Employee->Basic->find('list',array('conditions'=>array('Basic.basic_type'=>1)));
	$quotas = $this->Employee->Quota->find('list');
	$employeeTypes = $this->Employee->EmployeeType->find('list');
	$religions = $this->Employee->Religion->find('list');
	$jobStatuses = $this->Employee->JobStatus->find('list');
	$banks = $this->Employee->Bank->find('list');
	$sexes = $this->Employee->Sex->find('list');
	$maritalStatuses = $this->Employee->MaritalStatus->find('list');
	$livingStatuses = $this->Employee->LivingStatus->find('list');
	$this->loadModel('edu_status');
	$eduStatuses=$this->edu_status->find('list');
	$this->set(compact('employeeGrades', 'scales','departments', 'designations', 'basics', 'newBasics', 'quotas', 'employeeTypes', 'religions', 'jobStatuses', 'banks', 'sexes', 'maritalStatuses', 'livingStatuses','eduStatuses'));
}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
public function admin_delete($id = null) {
	if (!$this->request->is('post')) {
		throw new MethodNotAllowedException();
	}
	$this->Employee->id = $id;
	if (!$this->Employee->exists()) {
		throw new NotFoundException(__('Invalid employee'));
	}
	if ($this->Employee->delete()) {
		$this->Session->setFlash(__('Employee deleted'), 'flash/success');
		$this->redirect(array('action' => 'index'));
	}
	$this->Session->setFlash(__('Employee was not deleted'), 'flash/error');
	$this->redirect(array('action' => 'index'));
}
}
