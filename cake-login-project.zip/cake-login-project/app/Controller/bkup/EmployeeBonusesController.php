<?php
App::uses('AppController', 'Controller');
/**
 * EmployeeBonuses Controller
 *
 * @property EmployeeBonus $EmployeeBonus
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 */
class EmployeeBonusesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->set('page_title','Employee bonus List');

		######################################################################
		######### Employee bonus start 
		######################################################################

		$this->loadModel('FiscalYear');
		$FiscalYear =  $this->FiscalYear->find('list');

		$this->loadModel('Month');
		$Month =  $this->Month->find('list');

		$this->loadModel('ConfigMetas');
		$this->ConfigMetas->recursive = -1;
		$bonusType = $this->ConfigMetas->find('all', array('conditions' => array('ConfigMetas.key LIKE' => 'sal_%')));
		$this->set(compact('bonusType','FiscalYear','Month'));

		if ($this->request->is('post'))
		{
			$month_id = $this->request->data('month_id');
			$fiscal_year_id = $this->request->data('fiscal_year_id');
			$bonus = $this->request->data('bonus');

			if($bonus == 'eid_ul_fitr')
			{
				$percent =  $bonusType[2]['ConfigMetas']['value'];
				$tracking =  $bonusType[2]['ConfigMetas']['trackingId'];
				$relision = 1;
			}
			else if($bonus == 'eidul_azha')
			{
				$percent =  $bonusType[6]['ConfigMetas']['value'];
				$tracking =  $bonusType[6]['ConfigMetas']['trackingId'];
				$relision = 1;
			}
			else if($bonus == 'festival_hindu')
			{
				$percent =  $bonusType[3]['ConfigMetas']['value'];
				$tracking =  $bonusType[3]['ConfigMetas']['trackingId'];
				$relision = 2;
			}
			else if($bonus == 'festival_cristianity')
			{
				$percent =  $bonusType[4]['ConfigMetas']['value'];
				$tracking =  $bonusType[4]['ConfigMetas']['trackingId'];
				$relision = 3;
			}
			else if($bonus == 'festival_buddhisam')
			{
				$percent =  $bonusType[5]['ConfigMetas']['value'];
				$tracking =  $bonusType[5]['ConfigMetas']['trackingId'];
				$relision = 4;
			}
			
			$this->loadModel('Employee');

			if($bonus == 'pohela_boishakh')
			{
				$percent =  $bonusType[0]['ConfigMetas']['value'];
				$tracking =  $bonusType[0]['ConfigMetas']['trackingId'];

				$Employee = $this->Employee->find('all');
				
			}

			else
			{
				$Employee = $this->Employee->find('all', array('conditions' => array('Employee.religion_id' => $relision)));
			}

			$this->set(compact('percent','tracking','Employee','month_id','fiscal_year_id'));
		}

	    
	}


	public function admin_entry_bonus()
	{

		$this->EmployeeBonus->recursive = 2;

		if(empty($this->request->data))
		{
			$this->redirect(array('action' => 'index'));
		}

		$all = $this->request->data;
		$all_id =  $all['emp_id'];

		$entry_check = $this->EmployeeBonus->find('count',array('conditions' => array('EmployeeBonus.fiscal_year_id' => $all['fiscal_year_id'],'EmployeeBonus.month_id' => $all['month_id'], 'EmployeeBonus.festival_tracking_config_meta_id' => $all['tracking'])));
		if($entry_check > 0 )
		{
			$this->Session->setFlash(__('You Already Generate Bonus'), 'flash/error');
			//$this->redirect(array('action' => 'index'));

			$bonus = $this->EmployeeBonus->find('all',array('conditions' => array('EmployeeBonus.fiscal_year_id' => $all['fiscal_year_id'],'EmployeeBonus.month_id' => $all['month_id'], 'EmployeeBonus.festival_tracking_config_meta_id' => $all['tracking'])));
			//pr($bonus);
		}
		else
		{
			$this->loadModel('Employee');
			$this->Employee->recursive = 1;
			foreach ($all_id as  $v)
			{
				$res = $this->Employee->find('all', array('conditions' => array('Employee.id' => $v)));
				$data['employee_id'] = $res[0]['Employee']['id'];
				$data['current_basic'] = $res[0]['Scale']['grade_basic'];
				$data['scale_id'] = $res[0]['Employee']['scale_id'];

				$data['bonus_amount'] = ($res[0]['Scale']['grade_basic']*($all['percentage']/100));

				$data['percent'] = $all['percentage'];
				$data['fiscal_year_id'] = $all['fiscal_year_id'];
				$data['month_id'] = $all['month_id'];
				$data['user_id'] = $this->UserAuth->getUserId();
				$data['festival_tracking_config_meta_id'] = $all['tracking'];

				$data['created_at'] = $this->current_datetime();

				#########################################################
				### insert data using loop 
				##########################################################
				
				$this->EmployeeBonus->create();
				$this->EmployeeBonus->save($data);

				#########################################################
				### insert data using loop end
				##########################################################
			}

			$bonus = $this->EmployeeBonus->find('all',array('conditions' => array('EmployeeBonus.fiscal_year_id' => $all['fiscal_year_id'],'EmployeeBonus.month_id' => $all['month_id'], 'EmployeeBonus.festival_tracking_config_meta_id' => $all['tracking'])));
		}

		
 		$this->set(compact('all','all_id','bonus'));
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		$this->set('page_title','Employee bonus Details');
		if (!$this->EmployeeBonus->exists($id)) {
			throw new NotFoundException(__('Invalid employee bonus'));
		}
		$options = array('conditions' => array('EmployeeBonus.' . $this->EmployeeBonus->primaryKey => $id));
		$this->set('employeeBonus', $this->EmployeeBonus->find('first', $options));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		$this->set('page_title','Add Employee bonus');
		if ($this->request->is('post')) {
			$this->EmployeeBonus->create();
			$this->request->data['EmployeeBonus']['created_at'] = $this->current_datetime();
			$this->request->data['EmployeeBonus']['created_by'] = $this->UserAuth->getUserId();			
			if ($this->EmployeeBonus->save($this->request->data)) {
				$this->Session->setFlash(__('The employee bonus has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The employee bonus could not be saved. Please, try again.'), 'flash/error');
			}
		}
		$employees = $this->EmployeeBonus->Employee->find('list');
		$scales = $this->EmployeeBonus->Scale->find('list');
		$fiscalYears = $this->EmployeeBonus->FiscalYear->find('list');
		$months = $this->EmployeeBonus->Month->find('list');
		$users = $this->EmployeeBonus->User->find('list');
		$this->set(compact('employees', 'scales', 'fiscalYears', 'months', 'users'));
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
        $this->set('page_title','Edit Employee bonus');
		$this->EmployeeBonus->id = $id;
		if (!$this->EmployeeBonus->exists($id)) {
			throw new NotFoundException(__('Invalid employee bonus'));
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			$this->request->data['EmployeeBonus']['updated_by'] = $this->UserAuth->getUserId();
			if ($this->EmployeeBonus->save($this->request->data)) {
				$this->Session->setFlash(__('The employee bonus has been saved'), 'flash/success');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The employee bonus could not be saved. Please, try again.'), 'flash/error');
			}
		} else {
			$options = array('conditions' => array('EmployeeBonus.' . $this->EmployeeBonus->primaryKey => $id));
			$this->request->data = $this->EmployeeBonus->find('first', $options);
		}
		$employees = $this->EmployeeBonus->Employee->find('list');
		$scales = $this->EmployeeBonus->Scale->find('list');
		$fiscalYears = $this->EmployeeBonus->FiscalYear->find('list');
		$months = $this->EmployeeBonus->Month->find('list');
		$users = $this->EmployeeBonus->User->find('list');
		$this->set(compact('employees', 'scales', 'fiscalYears', 'months', 'users'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @throws MethodNotAllowedException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->request->is('post')) {
			throw new MethodNotAllowedException();
		}
		$this->EmployeeBonus->id = $id;
		if (!$this->EmployeeBonus->exists()) {
			throw new NotFoundException(__('Invalid employee bonus'));
		}
		if ($this->EmployeeBonus->delete()) {
			$this->Session->setFlash(__('Employee bonus deleted'), 'flash/success');
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('Employee bonus was not deleted'), 'flash/error');
		$this->redirect(array('action' => 'index'));
	}

	public function get_config_meta_comment($trackingId = null)
	{
		$this->loadModel('ConfigMeta');
		$comment = $this->ConfigMeta->find('all', array('fields' =>array('ConfigMeta.comment'), 'conditions' => array('trackingId' => $trackingId)));
		return $comment;
	}
}