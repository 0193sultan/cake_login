<?php
/**
 * Application level View Helper
 *
 * This file is application-wide helper file. You can put all
 * application-wide helper-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.View.Helper
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Helper', 'View');

/**
 * Application helper
 *
 * Add your application-wide methods in the class below, your helpers
 * will inherit them.
 *
 * @package       app.View.Helper
 */
class AppHelper extends Helper {
	
	var $helpers = array('Session');
	public $uses = array('Usermgmt.UserGroup');
	
	public function menu_permission($controller='',$action='')
	{
		App::import("Model", "Usermgmt.UserGroup");
		$UserGroup = new UserGroup(); 

		$group_id = $this->Session->read('UserAuth.User.user_group_id');
		$permissions = $UserGroup->getPermissions($group_id);
		$access = str_replace(' ','',ucwords(str_replace('_',' ',$controller))).'/'.$action;
		if (in_array($access, $permissions)) {
			return true;
		} 
		return false;  
	}
	
	
	public function dateformat($date='')
	{
		if($date=='0000-00-00' OR $date==NULL)
		return '';
		else
		return date('d-M-Y',strtotime($date));	
	}
	
	public function datetimeformat($datetime='')
	{
		if($datetime=='0000-00-00 00:00:00' OR $datetime==NULL)
		return '';
		else
		return date('d-M, Y  g:ia',strtotime($datetime)); 
	}
	
	public function expire_dateformat($date='')
	{
		if($date=='0000-00-00' OR $date==NULL)
		return '';
		else
		return date('m-y',strtotime($date)); 
	}
	
}
