<?php

App::uses('AppController', 'Controller');

class FilterAppController extends AppController {

}
